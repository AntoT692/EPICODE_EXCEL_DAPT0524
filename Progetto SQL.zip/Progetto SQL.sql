CREATE SCHEMA ToysGroup; -- creazione database negozio giocattoli 

/* Task 2: Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. 
Implementa fisicamente le tabelle utilizzando il DBMS SQL Server(o altro).  */

CREATE TABLE Category (
CategoryID INT NOT NULL 
, CategoryName VARCHAR (100)
, SubCategoryName VARCHAR (100)
, CONSTRAINT PK_CategoryID PRIMARY KEY (CategoryID));

ALTER TABLE category
DROP COLUMN SubCategoryName;

CREATE TABLE Product (
ProductKey INT NOT NULL 
, ProductName VARCHAR (100)
, StandardCost DECIMAL (10,2)
, CategoryID INT NOT NULL
, CONSTRAINT PK_ProductKey PRIMARY KEY (ProductKey)
, CONSTRAINT FK_CategoryID FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID) );

CREATE TABLE Region (
RegionID INT NOT NULL 
, RegionName VARCHAR (100)
, SubCategoryName VARCHAR (100)
, CONSTRAINT PK_RegionID PRIMARY KEY (RegionID) 
);

ALTER TABLE region
DROP COLUMN SubCategoryName;

CREATE TABLE Country (
CountryID INT NOT NULL
, CountryName VARCHAR (40)
, RegionID INT NOT NULL
, CONSTRAINT PK_CountryID PRIMARY KEY (CountryID)
, CONSTRAINT FK_Country_RegionID FOREIGN KEY (RegionID) REFERENCES Region(RegionID) 
); 

CREATE TABLE Sales (
SalesID VARCHAR (100) 
, OrderDate DATE 
, OrderQuantity INT 
, UnitPrice DECIMAL (10,2) 
, ProductKey INT NOT NULL 
, RegionID INT NOT NULL 
, CONSTRAINT PK_SalesID PRIMARY KEY (SalesID)
, CONSTRAINT FK_ProductKey FOREIGN KEY (ProductKey) REFERENCES Product(ProductKey) 
, CONSTRAINT FK_RegionID FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);


/* Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate)  */

INSERT INTO region (RegionID, RegionName)
VALUES
(1, 'North America')
, (2, 'South America')
, (3, 'Asia') 
, (4, 'Europa') 
, (5, 'Africa')
;

SELECT *
FROM region; 

INSERT INTO Category (CategoryID, CategoryName) VALUES
(1, 'Outdoor Toys'),
(2, 'Sports Equipment'),
(3, 'Board Games'),
(4, 'Action Figures'),
(5, 'Arts and Crafts'),
(6, 'Educational Toys'),
(7, 'Dolls and Plush Toys'),
(8, 'Vehicles and Trains'),
(9, 'Building Sets'),
(10, 'Water Toys'),
(11, 'Puzzles'),
(12, 'Musical Instruments'),
(13, 'Action Games'),
(14, 'Outdoor Sports'),
(15, 'Video Games'),
(16, 'Science Kits'),
(17, 'Dress-Up Clothes'),
(18, 'Remote Control Toys'),
(19, 'Gardening Kits'),
(20, 'Stuffed Animals');

SELECT *
FROM category;

INSERT INTO Product (ProductKey, ProductName, StandardCost, CategoryID) 
VALUES
(1, 'Adventure Board Game', 35.99, 3),
(2, 'Ultimate Frisbee', 12.99, 1),
(3, 'Electric Scooter', 199.99, 2),
(4, 'Space Action Figures', 24.99, 4),
(5, 'Crafting Kit', 15.49, 5),
(6, 'Outdoor Sports Set', 29.99, 14),
(7, '3D Puzzle', 22.00, 11),
(8, 'Eco-Friendly Water Bottle', 14.99, 10),
(9, 'Soft Toy Animal', 19.99, 20),
(10, 'Wooden Building Blocks', 27.50, 9),
(11, 'Remote Control Monster Truck', 60.00, 18),
(12, 'Mini Basketball Hoop', 45.00, 2),
(13, 'Art Supplies Set', 40.00, 5),
(14, 'Kids Science Experiment Kit', 39.99, 16),
(15, 'Toy Kitchen Set', 70.00, 5),
(16, 'Inflatable Pool Float', 22.00, 10),
(17, 'Kids Yoga Mat', 29.99, 6),
(18, 'Kids Golf Set', 49.99, 14),
(19, 'Outdoor Explorer Kit', 15.99, 1),
(20, 'Play-Doh Set', 12.50, 5),
(21, 'Kids Gardening Kit', 30.00, 19),
(22, 'Science Experiment Lab', 45.00, 16),
(23, 'Animal Safari Set', 29.99, 20),
(24, 'Dinosaur Figurine Set', 32.00, 20),
(25, 'Beach Toy Set', 18.00, 10),
(26, 'Sailing Boat Toy', 34.00, 8),
(27, 'Kids Plush Backpack', 34.99, 20),
(28, 'Magic Play Set', 20.00, 13),
(29, 'Kite with String', 15.00, 1),
(30, 'Robot Building Kit', 59.99, 18),
(31, 'Kids Dress-Up Clothes', 40.00, 17),
(32, 'Animal Masks Set', 18.00, 1),
(33, 'Kids Fishing Game', 18.00, 11),
(34, 'Kids Musical Instruments', 45.00, 12),
(35, 'Kids DIY Birdhouse', 22.00, 19),
(36, 'Bubble Machine', 30.00, 10),
(37, 'Magic Coloring Book', 12.00, 5),
(38, 'Kids Plush Toy Dog', 25.00, 20),
(39, 'Kids Gardening Tools', 15.00, 19),
(40, 'Bubble Wrap Roll', 5.00, 5),
(41, 'Remote Control Car', 50.00, 18),
(42, 'Kids First Aid Kit', 30.00, 6),
(43, 'Kids DIY Craft Kit', 25.00, 5),
(44, 'Animal Puzzle', 30.00, 11),
(45, 'Kids Binoculars', 15.99, 6),
(46, 'LED Light-Up Spinner', 10.00, 10),
(47, 'Outdoor Sports Ball', 25.00, 14),
(48, 'Kids Yoga Props', 12.00, 6),
(49, 'Jigsaw Puzzle for Kids', 20.00, 11),
(50, 'Kids Sand Play Set', 20.00, 10),
(51, 'Inflatable Bouncing Ball', 9.99, 10),
(52, 'Kids Fishing Rod', 15.00, 2),
(53, 'Karaoke Machine for Kids', 70.00, 12),
(54, 'Kids Bike Helmet', 25.00, 2),
(55, 'Kids Art Easel', 75.00, 5),
(56, 'Kids Roller Skates', 50.00, 14),
(57, 'Kids Trampoline', 200.00, 1),
(58, 'Kids Slide', 100.00, 1),
(59, 'Kids Mini Pool Table', 80.00, 3),
(60, 'Kids Table Tennis Set', 40.00, 2),
(61, 'Kids Bowling Set', 35.00, 13),
(62, 'Kids Snorkel Set', 30.00, 10),
(63, 'Water Balloon Kit', 15.00, 1),
(64, 'Bubble Bath Set', 12.00, 10),
(65, 'Craft Supplies Box', 20.00, 5),
(66, 'Kids Puzzle Box', 15.00, 11),
(67, 'Kids Bike', 100.00, 2),
(68, 'Kids Fishing Play Set', 25.00, 1),
(69, 'Kids Camping Gear', 45.00, 1),
(70, 'Kids Adventure Kit', 50.00, 19),
(71, 'Kids Trike', 75.00, 2),
(72, 'Kids Dance Mat', 40.00, 12),
(73, 'Kids Jump Rope', 10.00, 13),
(74, 'Kids Frisbee Set', 12.00, 1),
(75, 'Kids Animal Care Set', 20.00, 6),
(76, 'Kids Science Lab', 70.00, 16),
(77, 'Kids Gardening Gloves', 8.00, 19),
(78, 'Kids Playhouse', 250.00, 1),
(79, 'Kids Train Set', 45.00, 8),
(80, 'Kids Memory Game', 20.00, 3),
(81, 'Kids Art Set', 30.00, 5),
(82, 'Kids Guitar', 55.00, 12),
(83, 'Kids Play Tunnel', 40.00, 10),
(84, 'Kids Balance Bike', 70.00, 2),
(85, 'Kids Dollhouse', 120.00, 7),
(86, 'Kids Bike Accessories', 15.00, 2),
(87, 'Kids Skateboard', 50.00, 2),
(88, 'Kids Sled', 25.00, 1),
(89, 'Kids Snowball Maker', 12.00, 1),
(90, 'Kids Science Kits', 35.00, 16),
(91, 'Kids Remote Control Helicopter', 60.00, 18),
(92, 'Kids Animal Hand Puppets', 30.00, 20),
(93, 'Kids Activity Book', 10.00, 6),
(94, 'Kids Play Food Set', 25.00, 7),
(95, 'Kids Gardening Play Set', 30.00, 19),
(96, 'Kids Pet Care Kit', 20.00, 6),
(97, 'Kids Tool Set', 35.00, 5),
(98, 'Kids Sport Net Set', 40.00, 14),
(99, 'Kids Snack Set', 15.00, 7),
(100, 'Kids Winter Sports Gear', 45.00, 1);

SELECT*
FROM product;

INSERT INTO Country (CountryID, CountryName, RegionID) VALUES
(1, 'United States', 1),
(2, 'Canada', 1),
(3, 'Mexico', 1),
(4, 'Brazil', 2),
(5, 'Argentina', 2),
(6, 'Chile', 2),
(7, 'Colombia', 2),
(8, 'Germany', 4),
(9, 'France', 4),
(10, 'United Kingdom', 4),
(11, 'Italy', 4),
(12, 'Spain', 4),
(13, 'Sweden', 4),
(14, 'Netherlands', 4),
(15, 'Poland', 4),
(16, 'India', 3),
(17, 'Japan', 3),
(18, 'South Korea', 3),
(19, 'Singapore', 3),
(20, 'Thailand', 3),
(21, 'Vietnam', 3),
(22, 'Malaysia', 3),
(23, 'Egypt', 5),
(24, 'South Africa', 5),
(25, 'Nigeria', 5),
(26, 'Kenya', 5),
(27, 'Morocco', 5),
(28, 'Ghana', 5),
(29, 'United Arab Emirates', 3),
(30, 'Saudi Arabia', 3),
(31, 'Turkey', 3),
(32, 'Philippines', 3),
(33, 'Indonesia', 3),
(34, 'Bangladesh', 3),
(35, 'Pakistan', 3),
(36, 'Czech Republic', 4),
(37, 'Austria', 4),
(38, 'Switzerland', 4),
(39, 'Finland', 4),
(40, 'Denmark', 4),
(41, 'Hungary', 4),
(42, 'Slovakia', 4),
(43, 'Slovenia', 4),
(44, 'Portugal', 4),
(45, 'Iceland', 4),
(46, 'Bulgaria', 4),
(47, 'Lithuania', 4),
(48, 'Latvia', 4),
(49, 'Estonia', 4),
(50, 'Cyprus', 4);

SELECT*
FROM country;


INSERT INTO Sales (SalesID, OrderDate, OrderQuantity, UnitPrice, ProductKey, RegionID) 
VALUES
(1, '2024-01-05', 3, 90.00, 1, 1),
(2, '2024-01-15', 5, 180.00, 2, 1),
(3, '2024-01-20', 1, 90.00, 3, 2),
(4, '2024-01-25', 3, 120.00, 4, 2),
(5, '2024-02-01', 6, 150.00, 5, 3),
(6, '2024-02-05', 2, 60.00, 6, 3),
(7, '2024-02-10', 4, 110.00, 7, 4),
(8, '2024-02-15', 8, 85.00, 8, 4),
(9, '2024-02-20', 1, 100.00, 9, 1),
(10, '2024-02-25', 3, 45.00, 10, 1),
(11, '2024-03-01', 4, 150.00, 11, 2),
(12, '2024-03-05', 6, 95.00, 12, 2),
(13, '2024-03-10', 5, 70.00, 13, 3),
(14, '2024-03-15', 3, 140.00, 14, 3),
(15, '2024-03-20', 10, 200.00, 15, 4),
(16, '2024-03-25', 2, 85.00, 16, 4),
(17, '2024-04-01', 7, 60.00, 17, 1),
(18, '2024-04-05', 1, 20.00, 18, 1),
(19, '2024-04-10', 4, 130.00, 19, 2),
(20, '2024-04-15', 8, 80.00, 20, 2),
(21, '2024-04-20', 3, 60.00, 21, 3),
(22, '2024-04-25', 5, 40.00, 22, 3),
(23, '2024-05-01', 10, 95.00, 23, 4),
(24, '2024-05-05', 2, 55.00, 24, 4),
(25, '2024-05-10', 6, 70.00, 25, 1),
(26, '2024-05-15', 4, 100.00, 26, 1),
(27, '2024-05-20', 5, 60.00, 27, 2),
(28, '2024-05-25', 7, 130.00, 28, 2),
(29, '2024-06-01', 3, 40.00, 29, 3),
(30, '2024-06-05', 8, 85.00, 30, 3),
(31, '2024-06-10', 2, 30.00, 31, 4),
(32, '2024-06-15', 6, 90.00, 32, 4),
(33, '2024-06-20', 1, 75.00, 33, 1),
(34, '2024-06-25', 4, 120.00, 34, 1),
(35, '2024-07-01', 5, 150.00, 35, 2),
(36, '2024-07-05', 2, 45.00, 36, 2),
(37, '2024-07-10', 7, 60.00, 37, 3),
(38, '2024-07-15', 10, 90.00, 38, 3),
(39, '2024-07-20', 3, 75.00, 39, 4),
(40, '2024-07-25', 4, 100.00, 40, 4),
(41, '2024-08-01', 2, 30.00, 41, 1),
(42, '2024-08-05', 5, 130.00, 42, 1),
(43, '2024-08-10', 6, 80.00, 43, 2),
(44, '2024-08-15', 3, 55.00, 44, 2),
(45, '2024-08-20', 4, 70.00, 45, 3),
(46, '2024-08-25', 8, 90.00, 46, 3),
(47, '2024-09-01', 1, 200.00, 47, 4),
(48, '2024-09-05', 10, 40.00, 48, 4),
(49, '2024-09-10', 2, 150.00, 49, 1),
(50, '2024-09-15', 3, 80.00, 50, 1),
(51, '2024-09-20', 6, 70.00, 51, 2),
(52, '2024-09-25', 4, 85.00, 52, 2),
(53, '2024-09-30', 5, 60.00, 53, 3),
(54, '2024-10-05', 7, 95.00, 54, 3),
(55, '2024-10-10', 1, 150.00, 55, 4),
(56, '2024-10-15', 2, 80.00, 56, 4),
(57, '2024-10-20', 4, 130.00, 57, 1),
(58, '2024-10-25', 3, 70.00, 58, 1),
(59, '2024-11-01', 6, 60.00, 59, 2),
(60, '2024-11-05', 5, 90.00, 60, 2),
(61, '2024-11-10', 4, 50.00, 61, 3),
(62, '2024-11-15', 2, 70.00, 62, 3),
(63, '2024-11-20', 1, 80.00, 63, 4),
(64, '2024-11-25', 3, 75.00, 64, 4),
(65, '2024-12-01', 6, 120.00, 65, 1),
(66, '2024-12-05', 8, 100.00, 66, 1),
(67, '2024-12-10', 2, 40.00, 67, 2),
(68, '2024-12-15', 5, 90.00, 68, 2),
(69, '2024-12-20', 4, 60.00, 69, 3),
(70, '2024-12-25', 10, 130.00, 70, 3),
(71, '2024-01-05', 1, 150.00, 71, 4),
(72, '2024-01-10', 3, 80.00, 72, 4),
(73, '2024-01-15', 2, 60.00, 73, 1),
(74, '2024-01-20', 6, 95.00, 74, 1),
(75, '2024-01-25', 5, 70.00, 75, 2),
(76, '2024-01-30', 3, 55.00, 76, 2),
(77, '2024-02-05', 4, 90.00, 77, 3),
(78, '2024-02-10', 2, 70.00, 78, 3),
(79, '2024-02-15', 1, 100.00, 79, 4),
(80, '2024-02-20', 8, 50.00, 80, 4),
(81, '2024-02-25', 3, 85.00, 81, 1),
(82, '2024-03-02', 4, 95.00, 82, 1),
(83, '2024-03-05', 5, 150.00, 83, 2),
(84, '2024-03-10', 2, 80.00, 84, 2),
(85, '2024-03-15', 3, 90.00, 85, 3),
(86, '2024-03-20', 6, 60.00, 86, 3),
(87, '2024-03-25', 1, 70.00, 87, 4),
(88, '2024-04-01', 5, 100.00, 88, 4),
(89, '2024-04-05', 4, 80.00, 89, 1),
(90, '2024-04-10', 2, 50.00, 90, 1),
(91, '2024-04-15', 6, 150.00, 91, 2),
(92, '2024-04-20', 3, 70.00, 92, 2),
(93, '2024-04-25', 5, 90.00, 93, 3),
(94, '2024-04-30', 1, 60.00, 94, 3),
(95, '2024-05-05', 10, 130.00, 95, 4),
(96, '2024-05-10', 2, 80.00, 96, 4),
(97, '2024-05-15', 4, 150.00, 97, 1),
(98, '2024-05-20', 6, 70.00, 98, 1),
(99, '2024-05-25', 3, 60.00, 99, 2),
(100, '2024-05-30', 5, 90.00, 100, 2);

SELECT*
FROM sales;

/* Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a: */ 

/* 1) Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata). */

SELECT CategoryID,	
	COUNT(*) as Count
FROM category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

SHOW KEYS
FROM category;

SELECT ProductKey, 
	COUNT(*) AS Count
FROM Product
GROUP BY ProductKey
HAVING COUNT(*) > 1;

SHOW KEYS
FROM product;

SELECT RegionID, 
	COUNT(*) AS Count
FROM region
GROUP BY RegionID
HAVING COUNT(*) > 1; 

SHOW KEYS
FROM region;

SELECT CountryID, 
	COUNT(*) AS Count
FROM Country
GROUP BY CountryID
HAVING COUNT(*) > 1;

SELECT SalesID, 
	COUNT(*) AS Count
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

/* 2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita 
e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT 
	s.SalesID AS Document_Code
    , s.OrderDate AS Sale_Date
    , p.ProductName AS Product_Name
    , c.CategoryName AS Category_Name
    , cnt.CountryName AS Country_Name
    , r.RegionName AS Region_Name
,	CASE 
	WHEN (DATEDIFF(CURRENT_DATE, s.OrderDate) > 180) THEN 'TRUE'
    WHEN (DATEDIFF(CURRENT_DATE, s.OrderDate) <= 180) THEN 'FALSE'
END 'CHECK180'
FROM sales s
JOIN Product p ON s.ProductKey = p.ProductKey
JOIN Category c ON p.CategoryID = c.CategoryID
JOIN Country cnt ON s.RegionID = cnt.RegionID
JOIN Region r ON cnt.RegionID = r.RegionID;

/* 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto. */

SELECT s.ProductKey
, SUM(s.OrderQuantity) AS TotalQuantity
FROM Sales AS S
WHERE YEAR(s.OrderDate) = (SELECT 
                                MAX(YEAR(OrderDate)) 
                                FROM Sales)
GROUP BY s.ProductKey
HAVING SUM(s.OrderQuantity) > (SELECT 
                                 AVG(OrderQuantity)
                                 FROM Sales
WHERE YEAR(OrderDate) = (SELECT 
                                MAX(YEAR(OrderDate)) 
                                FROM Sales));
                                
/* 4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */ 

SELECT s.ProductKey, p.ProductName,
YEAR(OrderDate) AS Sale_Year,
SUM(s.OrderQuantity*s.UnitPrice) AS Total_Revenue 
FROM sales s
JOIN product p ON s.ProductKey = p.ProductKey
GROUP BY p.ProductKey, YEAR (s.OrderDate) 
ORDER BY p.ProductKey, Sale_Year;

/* 5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. */

SELECT YEAR(OrderDate) AS Sale_Year,
		cnt.CountryName,
		SUM(s.OrderQuantity*s.UnitPrice) AS Total_Revenue
FROM sales s
JOIN Country cnt ON s.RegionID = cnt.RegionID
GROUP BY YEAR (s.OrderDate), cnt.CountryName 
ORDER BY YEAR (s.OrderDate), Total_Revenue DESC;

/*6) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */

SELECT c.CategoryName AS Category,  
		SUM(s.OrderQuantity) AS Total_Quantity
FROM sales s
JOIN product p ON s.ProductKey = p.ProductKey
JOIN category c ON p.CategoryID = c.CategoryID
GROUP BY c.CategoryName
ORDER BY Total_Quantity DESC
LIMIT 1;

/* 7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti. 
APPROCCIO 1 */

SELECT s.ProductKey, p.ProductName
FROM sales s
LEFT JOIN product p ON s.ProductKey = p.ProductKey
WHERE s.ProductKey IS NULL;

/* 7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti. 
APPROCCIO 2 */

SELECT p.ProductKey 'Cod_prodotto',
       p.ProductName 'Nome_prodotto'
FROM Product p
WHERE p.ProductKey NOT IN (SELECT s.ProductKey
                          FROM Sales s);
                          
/* 8) Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
(codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW DenormalizedProductView AS
SELECT p.ProductKey AS 'CODICE_PRODOTTO',
		p.ProductName AS 'NOME_PRODOTTO',
        c.CategoryName AS 'Categoria'
FROM product p 
JOIN Category c ON p.CategoryID = c.CategoryID;

/* 9) Creare una vista per le informazioni geografiche */

CREATE VIEW GeographicInfoView AS
SELECT r.RegionID 'CODICE_REGIONE',
		cnt.CountryID 'CODICE_STATO',
        r.RegionName 'NOME_REGIONE',
        cnt.CountryName 'NOME_STATO'
FROM region r 
JOIN country cnt ON r.RegionID = cnt.RegionID




